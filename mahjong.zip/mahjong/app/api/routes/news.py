from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.services.news_service import get_news_service
from app.config.database import get_db
from app.models.news import NewsResponse

router = APIRouter()


@router.get("/", response_model=List[NewsResponse])
async def get_news_list(
        skip: int = 0,
        limit: int = 10,
        db: Session = Depends(get_db)
):
    news_service = get_news_service(db)
    news_list = await news_service.get_news_list(skip, limit)
    return news_list


@router.get("/{news_id}", response_model=NewsResponse)
async def get_news_detail(
        news_id: str,
        db: Session = Depends(get_db)
):
    news_service = get_news_service(db)
    news = await news_service.get_news_by_id(news_id)
    if not news:
        raise HTTPException(status_code=404, detail="新闻不存在")

    # 增加浏览数
    await news_service.increment_view_count(news_id)

    return news